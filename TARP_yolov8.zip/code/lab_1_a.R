#1

days_in_month <- c(31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)


#2
days_in_month <- c(31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
days_in_month_integer <- as.integer(days_in_month)
print(days_in_month_integer)

days_in_month_logical <- as.logical(days_in_month)
print(days_in_month_logical)

days_in_month_character <- as.character(days_in_month)
print(days_in_month_character)

days_in_month_complex <- as.complex(days_in_month)
print(days_in_month_complex)

#3
ug_programs <- c("B.Tech CSE", "B.Tech Electronics", "B.Tech Mechanical", "B.Tech Civil", "B.Com", "LLB", "MIA" , "fashion")
print(ug_programs)
total_programs <- length(ug_programs)
cat("Total U.G programs:", total_programs)

#4
RegNo <- "20MIA1006"
Name <- "sanidhya chaudhary"
Age <- 21
Gender <- "male"
City <- "haridwar"
MyInfo <- c(RegNo, Name, Age, Gender, City)
print(MyInfo)
print(class(MyInfo))
MyInfo_as_integer <- as.integer(MyInfo)
print(MyInfo_as_integer)

#5
alphabet_vector <- letters
last_vector <- c(0)
vector <- c(alphabet_vector, last_vector)
alphabet_matrix <- matrix(vector, nrow = 3, byrow = TRUE)
print(alphabet_matrix[2,7])
second_row <- alphabet_matrix[2, ]
print(second_row)
num_letters_in_second_row <- length(second_row)
print(num_letters_in_second_row)
fifth_letter_in_third_row <- alphabet_matrix[3, 5]
print(fifth_letter_in_third_row)

#6
matrix_a <- matrix(1:12, nrow = 3, byrow = TRUE)
print(matrix_a)
dim(matrix_a) <- c(2, 6)
print(matrix_a)



#7
#i)- matrices m1 and m2
m1 <- matrix(1:9, nrow = 3, byrow = TRUE)
m2 <- matrix(11:19, nrow = 3, byrow = TRUE)

#ii)- Printing matrices m1 and m2

print(m1)


print(m2)

#iii)-
p1 <- rbind(m1, m2)
p1[p1 <= 10] <- p1[p1 <= 10] - 1

print(p1)

# iv)- Combining matrices m1 and m2 with all elements in the last column exceeding 16
p2 <- cbind(m1, m2[, 1:2] + 7)

print(p2)

