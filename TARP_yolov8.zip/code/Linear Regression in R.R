#20MIA1006
#SANIDHYA CHAUDHARY
#FDA LAB -- Linear Regression in R


# Load the required packages
library(readr)

#Step 1: Load the dataset - This dataset was inspired by the book Machine Learning with R by Brett Lantz. 
#The data contains medical information and costs billed by health insurance companies. 


# Read the dataset
dataset <- read_csv("C:/Users/SHIVA/Downloads/insurance.csv") 
dataset
# Retrieve the full column specification
column_spec <- spec(dataset)
column_spec

#Step 2: Find the correlation

library(ggplot2)

#install.packages("corrplot")
#Load the corrplot library
library(corrplot)

# Correlation between input variables & output variable (charges)
correlation_output <- cor(dataset[, c("age", "bmi", "children")], dataset$charges)
correlation_output
# Correlation among input variables
correlation_input <- cor(dataset[, c("age", "bmi", "children")])
correlation_input

# Create correlation plots.It then prints and plots the correlation matrices for visualization.
corrplot(correlation_output, method = "color")
corrplot(correlation_input, method = "color")

#STEP:3--> Check for multicollinearity using Variance Inflation Factor (VIF)
# Load necessary library
#install.packages("car")
library(car)

# Fit a linear model to calculate VIF
lm_model <- lm(charges ~ age + bmi + children, data = dataset)

# Calculate VIF
vif_values <- vif(lm_model)

# Print VIF values
print(vif_values)

# Check for multicollinearity (VIF > 10 is considered high multicollinearity)
high_vif <- vif_values > 10
if (any(high_vif)) {
  cat("High multicollinearity detected for variables:\n")
  print(names(vif_values[high_vif]))
  # You may consider removing one of the highly correlated variables
} else {
  cat("No high multicollinearity detected.\n")
}

#This code fits a linear model and calculates the Variance Inflation Factor (VIF) for each predictor variable. 
#It then checks for multicollinearity by looking for variables with VIF values greater than 10.

# Fit a linear regression model
lm_model <- lm(charges ~ age + bmi + children, data = dataset)

# Residuals vs. Fitted plot (linearity)
plot(lm_model, which = 1)

# Normal Q-Q plot (normality)
plot(lm_model, which = 2)

# Scale-Location plot (homoscedasticity)
plot(lm_model, which = 3)

# Cook's distance plot (outliers)
plot(lm_model, which = 4)

#This above code fits a linear regression model and checks various assumptions using diagnostic plots. 
#It checks linearity, normality of residuals, homoscedasticity, and identifies potential outliers using Cook's distance.

# Fit a linear regression model with all input variables
lm_model <- lm(charges ~ age + bmi + children, data = dataset)

# Print regression summary
summary(lm_model)

# Extract the coefficients
coefficients <- coef(lm_model)

# Extract the intercept
intercept <- coefficients[1]

# Extract the slopes for other variables
slopes <- coefficients[-1]

# Create a character vector for variable names
variable_names <- c("Intercept", "Age", "BMI", "Children")

# Create a character vector for the slopes
slopes_strings <- paste(variable_names[-1], " * ", round(slopes, 2), sep = "")

# Combine the intercept and slopes into the regression equation
regression_equation <- paste("y =", round(intercept, 2), "+", paste(slopes_strings, collapse = " + "))

# Print the regression equation
cat("Regression Equation:\n", regression_equation, "\n")


#  performance metrics
# Predict charges using the linear regression model
predicted_charges <- predict(lm_model, newdata = dataset)

# Calculate Mean Absolute Error (MAE)
mae <- mean(abs(dataset$charges - predicted_charges))

# Calculate Mean Square Error (MSE)
mse <- mean((dataset$charges - predicted_charges)^2)

# Calculate Root Mean Square Error (RMSE)
rmse <- sqrt(mse)

# Calculate R-squared
rsquared <- summary(lm_model)$r.squared

# Calculate Adjusted R-squared
adjusted_rsquared <- summary(lm_model)$adj.r.squared

# Print performance metrics
cat("Mean Absolute Error (MAE): ", mae, "\n")
cat("Mean Square Error (MSE): ", mse, "\n")
cat("Root Mean Square Error (RMSE): ", rmse, "\n")
cat("R-Squared: ", rsquared, "\n")
cat("Adjusted R-squared: ", adjusted_rsquared, "\n")
