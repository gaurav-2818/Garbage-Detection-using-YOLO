# 1.
temp <- c(8, 12, 17, 20, 32 , 35 , 40, 42, 37, 32, 20, 15)
print(temp)

# 2. Converting to different data types
int_temp <- as.integer(temp)
logical_temp <- as.logical(temp)
char_temp <- as.character(temp)
complex_temp <- as.complex(temp)

print(int_temp)
print(logical_temp)
print(char_temp)
print(complex_temp)


#3.
fruits <- c("Apple", "Banana", "Mango", "Orange", "Grapes")
print(fruits)
cat("Total number of fruits:", length(fruits))

#4
# Creating a data frame
data <- data.frame(
RegNo = c(1001, 1002, 1003),
Name = c("rohit", "deep", "shiva"),
Age = c(21, 22, 23),
Gender = c("Male", "Female", "Male"),
City = c("delhi", "goa", "chennai")
)
# 4 a.  
print(data)

# 4 b.
cat("Type of 'data' data frame:", class(data))

#5

# Creating the alphabet vector
alphabet <- letters

# a.
alphabet_matrix <- matrix(alphabet, nrow = 2, ncol = 13, byrow = TRUE)

# b.
print(alphabet_matrix[1, 11])

# c.
second_row <- alphabet_matrix[2, ]
print(second_row)
cat("Number of letters in the 2nd row:", length(second_row))

# d.
print(alphabet_matrix[1, 8])


#6
# Creating the matrix
matrix_3x4 <- matrix(1:12, nrow = 3)

# Applying attributes
dim(matrix_3x4) <- c(3, 4)
colnames(matrix_3x4) <- c("Column 1", "Column 2", "Column 3", "Column 4")

print(matrix_3x4)
