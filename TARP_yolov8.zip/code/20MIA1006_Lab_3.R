#20mia1006
#sanidhyavchaudhary FDA LAB 3

#install.packages("nycflights13")
#install.packages("dplyr")
#library(dplyr)
library(nycflights13)

#1. Filter for flights with an arrival delay of two or more hours
delay_two_hours_or_more <- flights 
filter(arr_delay >= 120)
delay_two_hours_or_more



#2. Filter for flights with an arrival delay of no more than one hour
delay_one_hour_or_less <- flights 
filter(arr_delay <= 60)
delay_one_hour_or_less
#3.Count the number of flights with missing dep_time
missing_dep_time <- sum(is.na(flights$dep_time))
missing_dep_time
#4. Filter for flights that are not operated by American Airlines
not_operated_by_aa <- flights 
filter(carrier != "AA")
not_operated_by_aa
#5. Filter for flights that departed during July 2013
july_2013 <- flights 
filter(month == 7)
july_2013
#6. Find the most delayed flights considering their arrival time alone
most_delayed_by_arrival <- flights %>%
  arrange(desc(arr_delay)) %>%
  head(1)
most_delayed_by_arrival
#7. Filter for flights that operate between LGA and IAH airports
lga_iah <- flights %>%
  filter(origin == "LGA" & dest == "IAH")
lga_iah
#8. ilter for flights that has the destination of IAH
iah_destination <- flights %>%
  filter(dest == "IAH")
iah_destination
#9. ind the flight that covers the longest distance
longest_distance <- flights %>%
  arrange(desc(distance)) %>%
  head(1)
longest_distance
shortest_distance <- flights %>%
  arrange(distance) %>%
  head(1)
shortest_distance
#10. Calculate the average delay for each carrier
average_delay_per_carrier <- flights %>%
  group_by(carrier) %>%
  summarize(average_delay = mean(arr_delay))
worst_delays <- average_delay_per_carrier %>%
  arrange(desc(average_delay)) %>%
  head(1)
worst_delays







#Q-3_B)-->

#1.)-What month had the highest proportion of cancelled flights?

flights2 <- flights %>%
  group_by(month) %>%
  summarize(cancelled =  sum(is.na(arr_delay)),
            total = n(),
            prop_cancelled = cancelled/total) %>%
  arrange(desc(prop_cancelled)) 

flights2

#2)-How many planes that flew from NYC have a missing date of manufacturer?
planes %>% summarise(sum(is.na(year) == TRUE))




