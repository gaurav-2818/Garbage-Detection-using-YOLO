#20MIA1006
#SANIDHYA CHAUDHARY

#The variables on our extracted dataset are pclass, survived, name, age, embarked, 
#home.dest, room, ticket, boat, and sex. pclass refers to passenger class (1st, 2nd, 3rd), 
#and is a proxy for socio-economic class. Age is in years, and some infants had 
#fractional values.



#PACKAGES VALUE

library(tidyverse)
library(stringr)
library(DataExplorer)
library(GGally)
library(magrittr)
library(ggrepel)
library(gridExtra)
library(tidytext)

#DATA LOADING

train <- read.csv("C:/Users/SHIVA/Downloads/train.csv")
head(train)

test <- read.csv("C:/Users/SHIVA/Downloads/test.csv")
head(test)

#DATA INSIGHTS USING INBUILT FUNCTIONS
glimpse(train)

glimpse(test)

plot_intro(train)
plot_intro(test)

plot_str(train)
plot_str(test)

dim(train)
view(train)

summary(train)

#DATA PREPROCESSING

any(is.na(train))
sum(is.na(train))

# Missing Values
plot_missing(train)

plot_correlation(train)

#INFERENCES BY CORRELATION
#Positive and Negative values denote Positive and Negative correlation. 
#The first row of the data shows the correlation of each variable with 
#the Target variable ‘Survived’.




#Box plots are used to show distributions of numeric data values,
#especially when you want to compare them between multiple groups.
#below are some important boxplots which shows data insights
#Q-1-->survivors from each of P Class 

grid.arrange(
  ggplot(train, aes(Pclass, fill = Survived))+
    geom_bar()+
    coord_flip()+
    theme_minimal()+
    scale_fill_brewer(palette = 12)+
    labs(title = "Survival of Pclass",
         y = NULL)+
    theme(legend.position = "bottom"),
  
  ggplot(test, aes(Pclass))+
    geom_bar(fill = "slategray3")+
    coord_flip()+
    theme_minimal()+
    ylab("Frequency")
)


grid.arrange(
  ggplot(train, aes(Sex, fill = Survived))+
    geom_bar()+
    coord_flip()+
    theme_minimal()+
    scale_fill_brewer(palette = 13)+
    labs(title = "Survival of Sex",y = NULL)+
    theme(legend.position = "bottom"),
  
  ggplot(test, aes(Sex))+
    geom_bar(fill = "pink")+
    coord_flip()+
    theme_minimal()+
    ylab("Frequency")        
)


#survival of age
grid.arrange(
  
  ggplot(train, aes(Age, color = Survived))+
    geom_freqpoly()+
    theme_minimal()+
    labs(title = "Survival of Age",
         x = NULL,
         y = "Frequency")+
    theme(legend.position = "bottom"),
  
  ggplot(test, aes(Age))+
    geom_freqpoly()+
    theme_minimal()+
    ylab("Freqeuncy")
  
)


#no. of people survived
train %>% 
  ggplot(aes(x = Survived)) +
  geom_bar(width = 0.4) +
  theme_classic() +
  theme(
    plot.title = element_text(family = "Times New Roman", hjust = 0.5),
    axis.text = element_text(family = "Times New Roman",face = "bold"),
    axis.title = element_text(family = "Times New Roman", face = "bold")
  ) +
  labs(title = "Overall Survival Rates", x = "people survived", y = "Passenger count")

#Survival rates by Sex
train %>% 
  ggplot(aes(x = Sex, fill = Survived)) +
  geom_bar(width = 0.4) +
  theme_classic() +
  theme(
    plot.title = element_text(family = "Times New Roman", hjust = 0.5),
    axis.text = element_text(family = "Times New Roman",face = "bold"),
    axis.title = element_text(family = "Times New Roman", face = "bold"),
    legend.title = element_blank(),
    legend.text = element_text(family = "Times New Roman")
    
  ) +
  labs(title = "Survival rates by Sex", x = NULL, y = "Passenger count")




#INFERENCES--> Study of the target variable is a significant step in Data Analysis
#that reveals the nature and distribution of the variable. 
#Let’s analyze our target variable “Survived”.

barplot(sort(table(train$Pclass),decreasing=TRUE))


barplot(sort(table(train$Survived),decreasing=TRUE))


barplot(sort(table(train$Sex),decreasing=TRUE))


barplot(sort(table(train$Embarked),decreasing=TRUE))


train%>%
  select(Pclass)%>%
  count(Pclass)%>%
  arrange(desc(n))%>%
  view()


view(train[is.na(train$age),])
is.na(train)

summary(train$Fare)
boxplot(train$Fare)

hist(train$Fare)

unique(train$SibSp)
unique(train$Parch)
unique(train$Pclass)

# show people with Pclass =2 and  of age greater than 20
train%>%
  filter(Pclass==2 & Age>20)%>%
  select(Name, Survived, Sex, Fare, Age)%>%
  arrange(-Age)%>%
  view()

#mean age by avoiding NA values
mean(train$Age, na.rm= TRUE)
mean(train$Fare, na.rm= TRUE)

# find rows not having complete cases
train%>%
  filter(!complete.cases(.))%>%
  view()


