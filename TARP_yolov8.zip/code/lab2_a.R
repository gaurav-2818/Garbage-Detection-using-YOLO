#20mia1006    SANIDHYA CHAUDHARY 
#LAB_2_A AND LAB_2_B


#Create a list for an employee with the following fields:EmpId, Name,Designation, CompanyName
employee <- list(EmpId = "1",Name = "shiva",Designation = "IT head",CompanyName = "infosys")

#Q 2. Add the fields viz., DateOfBirth, ContactNumber and MailID to theabove list.

employee$DateOfBirth <- "2000-03-24"
employee$ContactNumber <- "9548624522"
employee$MailID <- "shivaghij@gmail.com"
employee

#Q 3. Print the total number of fields and the field names.

num_fields <- length(employee)
field_names <- names(employee)
cat("Total number of fields:", num_fields, "\n")
cat("Field names:", field_names, "\n")

#Q 4. Create a data frame with the above fieldnames (5 different variables for EmpId, Name, Designation, Company, DOB) for 5 employees.

employee_df <- data.frame(EmpId = c(001,002,003,004,005),Name = c("shiva","shri","rohit","Sanidhya","harshit"),
                          Designation = c("Software Engineer","Data Analyst","Product Manager","IT head","Marketing Head"),
                          CompanyName = c("infosys","JP Morgan","TCS","de shaw","google"),
                          DateOfBirth = as.Date(c("1998-06-1","1988-09-23","1995-03-10","1997-11-30","1999-06-18")))
# Print employee data frame
print(employee_df)


#Q 5. Add the ContactNumber and MailID to this dataframe.

employee_df$ContactNumber <- c("9119086885", "9876543210", "7885265442", "8546127596", "9578523655")
employee_df$MailID <- c("shiva@example.com", "shri@example.com", "rohit@example.com", "sanidhya@example.com", "harshit@example.com")
employee_df

#Q 6. Add the details of employee 3 without contact number and employee 4 without mentioning mailID.

# Add a new employee record without mail ID and contact number

employee_df <- rbind(employee_df, c("06", "abhishek", "Sales head", "accenture", "1995-06-18", NA, NA))
employee_df <- rbind(employee_df,c("07", "shreyas", "HR head", "TVS", "1999-07-29", NA, NA))
# Print updated employee data frame
employee_df

#Q 7. Display the details of the employees after removing the missing values.

employee_df_cleaned <- na.omit(employee_df)
print(employee_df_cleaned)

#Q 8. Calculate the age of all the employees and add it as an additional field

employee_df$Age <- as.integer(difftime(Sys.Date(), as.Date(employee_df$DateOfBirth), units = "days") / 365)
# Print updated employee data frame
print(employee_df)


#Q 9. Add the date of joining information to every employee.
employee_df$DateOfJoining <- as.Date(c("2020-01-15", "2018-08-10", "2022-03-20", "2019-11-05", "2021-06-30","2022-05-05","2023-02-25"))
employee_df

##Q 10 10.Print the experience (in terms of years, months and day) of employee1 at this company till Dec 31, 2022.
employee1_joining_date <- employee_df$DateOfJoining[1]
target_date <- as.Date("2022-12-31")
experience_days <- as.numeric(difftime(target_date, employee1_joining_date, units = "days"))
# Calculate years, months, and days
experience_years <- floor(experience_days / 365.25)
remaining_days <- experience_days %% 365.25
experience_months <- floor(remaining_days / 30.44)
experience_remaining_days <- round(remaining_days %% 30.44)

# Print experience of Employee 1
cat("Experience of Employee 1 until Dec 31, 2022:",
    experience_years, "years,", experience_months, "months,", experience_remaining_days, "days\n")


## 11.Print the age of employee2 at the time of joining in his company

employee2_joining_date <- employee_df$DateOfJoining[2]
employee2_dob <- employee_df$DateOfBirth[2]
age_at_joining <- as.integer(difftime(employee2_joining_date, employee2_dob, units = "days") / 365.25)

# Print age of Employee 2 at the time of joining
cat("Age of Employee 2 at the time of joining:", age_at_joining, "years\n")




### LAB 2 B

##Q1 Create a list of cities in different countries. Add the population and area (in square kilometers) for each city as additional fields.
#Print the total number of cities in the list.

# Create a list of cities with population and area
city_list <- list(
  City1 = c(Name = "New York", Population = 8376000, Area = 783.84),
  City2 = c(Name = "Tokyo", Population = 9273000, Area = 2187.66),
  City3 = c(Name = "London", Population = 8674000, Area = 1572),
  City4 = c(Name = "Mumbai", Population = 18410000, Area = 603.4)
)

# Print total number of cities in the list
cat("Total number of cities:", length(city_list), "\n")

##Q2 Create a data frame to store information about books. Include columns for Title, Author, Year of Publication, and Genre. 
#Add information for 6 different books.

# Create a data frame for books
books_df <- data.frame(
  Title = c("To Kill a Mockingbird", "1984", "The Great Gatsby", "Pride and Prejudice", "The Hobbit", "The Catcher in the Rye"),
  Author = c("Harper Lee", "George Orwell", "F. Scott Fitzgerald", "Jane Austen", "J.R.R. Tolkien", "J.D. Salinger"),
  Year = c(1960, 1949, 1925, 1813, 1937, 1951),
  Genre = c("Fiction", "Dystopian", "Classics", "Romance", "Fantasy", "Coming-of-age")
)

# Print the data frame
print(books_df)

##Q3 Add a new book entry to the existing data frame created in the previous question.
# Add a new book entry to the data frame
new_book <- data.frame(
  Title = "Harry Potter and the Sorcerer's Stone",
  Author = "J.K. Rowling",
  Year = 1997,
  Genre = "Fantasy"
)
books_df <- rbind(books_df, new_book)

# Print the updated data frame
print(books_df)


##Q4 Calculate the average year of publication for the books in the data frame.

average_year <- mean(books_df$Year)
cat("Average year of publication:", round(average_year), "\n")

##Q5 Create a list of students with their names, ages, and favorite subjects. Convert the list into a data frame.

# Create a list of students
students_list <- list(
  Student1 = c(Name = "Ramesh", Age = 18, FavoriteSubject = "Math"),
  Student2 = c(Name = "Babulal", Age = 17, FavoriteSubject = "Science"),
  Student3 = c(Name = "chetan", Age = 16, FavoriteSubject = "History"),
  Student4 = c(Name = "Dhruv", Age = 18, FavoriteSubject = "English")
)

# Convert the list into a data frame
students_df <- as.data.frame(students_list)

# Print the data frame
print(students_df)

##Q 6 Create a data frame with information about movies, including Title, Director, Release Year, and Genre. 
#Add details for at least 5 different movies.

# Create a data frame for movies
movies_df <- data.frame(
  Title = c("Inception", "The Shawshank Redemption", "Avatar", "Pulp Fiction", "Jurassic Park"),
  Director = c("Christopher Nolan", "Frank Darabont", "James Cameron", "Quentin Tarantino", "Steven Spielberg"),
  ReleaseYear = c(2010, 1994, 2009, 1994, 1993),
  Genre = c("Science Fiction", "Drama", "Science Fiction", "Crime", "Adventure")
)

# Print the data frame
print(movies_df)

##Q 7 Filter the movies data frame to include only movies released after the year 2000.

recent_movies <- subset(movies_df, ReleaseYear > 2000)
# Print the filtered data frame
print(recent_movies)

##Q8  Create a data frame to store information about products, including ProductName, Price, Category, and Quantity.
#Add details for at least 6 different products.

# Create a data frame for products
products_df <- data.frame(
  ProductName = c("Laptop", "Smartphone", "Headphones", "Tablet", "Camera", "Printer"),
  Price = c(1000, 700, 150, 300, 400, 200),
  Category = c("Electronics", "Electronics", "Accessories", "Electronics", "Electronics", "Office Supplies"),
  Quantity = c(10, 15, 20, 8, 5, 12)
)

# Print the data frame
print(products_df)

##Q9 Add a new column to the products data frame to calculate the total cost of each product (Price multiplied by Quantity).

products_df$TotalCost <- products_df$Price * products_df$Quantity
# Print the updated data frame
print(products_df)

##Q10 Sort the products data frame in descending order based on the total cost of each product.

sorted_products_df <- products_df[order(products_df$TotalCost, decreasing = TRUE), ]
# Print the sorted data frame
print(sorted_products_df)

##Q11 Create a nested list called student_info containing fields for Name, Age, and Address (with fields Street, City, and PostalCode). Print the street address of the student.

# Create a nested list for student information
student_info <- list(
  Name = "John",
  Age = 20,
  Address = list(
    Street = "123 Main St",
    City = "New York",
    PostalCode = "10001" ))
# Print the street address
print(student_info$Address$Street)

##Q12 Create a list numbers containing a sequence of numbers from 1 to 5. Double each number in the list and store the result in a new list called doubled_numbers. 
#Print both lists.

numbers <- list(1, 2, 3, 4, 5)
# Double each number in the list
doubled_numbers <- lapply(numbers, function(x) x * 2)
# Print both lists
print(numbers)
print(doubled_numbers)


##Q13 Create a list grades containing student grades (A, B, C, D, F). Use the unlist() function to convert the 
#list to a vector and calculate the average grade.

grades <- list("A", "B", "C", "D", "F")
# Convert the list to a vector
grades_vector <- unlist(grades)
# Calculate the average grade
average_grade <- mean(as.numeric(factor(grades_vector), levels = c("F", "D", "C", "B", "A")))
cat("Average grade:", average_grade, "\n")

##Q14 Create a list ages containing age values. Use the sapply() function to calculate the square of each age.

ages <- list(25, 30, 22, 28, 35)
# Calculate the square of each age using sapply
squared_ages <- sapply(ages, function(x) x^2)
# Print the list of squared ages
print(squared_ages)

##Q15 Create a list numbers containing numeric values. Use the Reduce() function to calculate the 
#product of all numbers in the list.

numbers <- list(2, 3, 4, 5)
# Calculate the product of all numbers using Reduce
product <- Reduce(`*`, numbers)
cat("Product of numbers:", product, "\n")

